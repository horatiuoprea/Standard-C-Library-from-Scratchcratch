#ifndef	__STRING_H__
#define	__STRING_H__	1

#ifdef __cplusplus
extern "C" {
#endif

struct timespec
{
    /* data */
    long rqtp, rmtp;
};


#ifdef __cplusplus
}
#endif

#endif